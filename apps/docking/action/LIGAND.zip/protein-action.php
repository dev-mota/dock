<?php
include "../pdbthorbox/pdbthorbox.php";
include_once "../lib/utils/utils.php";
include '../lib/utils/file-validator.php';

session_start ();
$session_id = session_id ();

$action = '';

if (isset ( $_FILES ['files'])) {
	$action = $_POST ['action'];
} else {
	$postdata = file_get_contents ( "php://input" );
	$request = json_decode ( $postdata );
	$action = $request->params->action;
}

if(isset ( $_GET ['action'])){
	$action = $_GET ['action'];
}

$response = array();
$utils = new Utils();

if ( isset($action) && ($session_id!=null) ) {
	if($action=='PREPARE'){
		$file_name = $request->params->fileName;
		$prepare_result = pdbthorboxPrepare($session_id, $file_name);
		
		if ($prepare_result['SUCCESS']) {
			$response['operationStatus'] = 'SUCCESS';
			$response['chains'] = $prepare_result['CHAINS'];
		} else {
			$response['operationStatus'] = 'ERROR';
			$response['errorMessage'] = 'Invalid File Structure';
		}
		
	} else if ($action=='PREPARE-TEST-FILE'){
		$session_dir = "../session-files/$session_id";
		if (! file_exists ( $session_dir ) || ! is_dir ( $session_dir )) {
			mkdir ( $session_dir );
		}
		
		$protein_dir = "$session_dir/PROTEIN";
		if (! file_exists ( $protein_dir ) || ! is_dir ( $protein_dir )) {
			mkdir ( $protein_dir );
		} else {
			$utils->clearDir ( $protein_dir );
		}
		copy ( '../test-files/php1caqPdb', "$protein_dir/1caq.pdb" );
	
		$prepare_result = pdbthorboxPrepare($session_id, '1caq.pdb');
		if ($prepare_result['SUCCESS']) {
			$response['operationStatus'] = 'SUCCESS';
			$response['chains'] = $prepare_result['CHAINS'];
		} else {
			$response['operationStatus'] = 'ERROR';
			$response['errorMessage'] = 'Invalid File Structure';
		}
		
	} else if ($action=='DOWNLOAD-FILE') {
		$file_type = $_GET['type'];
		$file_name = preg_replace ( '/\\.[^.\\s]{2,3}$/', '', $_GET['fileName'] ); // retirando extensão
		switch ($file_type) {
			case 'zip' :
				header ( "Location: ../session-files/$session_id/PROTEIN/$file_name.zip" );
				break;
			case 'prep' :
				header ( "Location: ../session-files/$session_id/PROTEIN/$file_name" . "_prep.pdb" );
				break;
			case 'in' :
				$file = "../session-files/$session_id/PROTEIN/$file_name.in";
				header("Cache-Control: public");
				header("Content-Description: File Transfer");
				header("Content-Disposition: attachment; filename=$file_name.in");
				header("Content-Type: application/zip");
				header("Content-Transfer-Encoding: binary");
					
				// read the file from disk
				readfile($file);
				break;
			case 'pdb' :
				header ( "Location: ../session-files/$session_id/PROTEIN/$file_name.pdb" );
				break;
			default :
				break;
		}
	} else if ($action=='SAVE-FILE'){
		$session_dir = "../session-files/$session_id";
		if (! file_exists ( $session_dir ) || ! is_dir ( $session_dir )) {
			mkdir ( $session_dir );
		}
		
		
		$response ["files"] = array ();
		$response['operationStatus'] = 'STARTING';
		
		$fileNameId = substr ( md5 ( microtime () ), rand ( 0, 26 ), 10 );
		$fileExtension = array_pop ( explode ( '.', $_FILES ['files'] ['name'] ) );
		
		if(!($fileExtension == "pdb" || $fileExtension == "in")){
			$response['operationStatus'] = 'ERROR';
			$response['errorMessage'] = 'File type not allowed';
		}
		$fileNameId = "protein_$fileNameId";
		saveFile ( $_FILES ['files'], "$session_dir/PROTEIN", "$fileNameId.$fileExtension" );
		
		if($response['operationStatus'] != 'ERROR'){
			if (FileValidator::isEmpty ( "$session_dir/PROTEIN/$fileNameId.$fileExtension" )) {
				$response['operationStatus'] = 'ERROR';
				$response['errorMessage'] = 'Empty file';
			} else {
				$response['operationStatus'] = 'SUCCESS';
				$file = array ();
				// $file["name"] = $_FILES ['files']['name'];
				$file ["name"] = $fileNameId;
				$file ["size"] = $_FILES ['files'] ['size'];
				$file ["thumbnailUrl"] = "apps/docking/session-files/$session_id/PROTEIN/" . $_FILES ['files'] ['name'];
				$file ["deleteUrl"] = "apps/docking/session-files/$session_id/PROTEIN/" . $_FILES ['files'] ['name'];
				$file ["deleteType"] = "DELETE";
				$file ["state"] = "pending";
				$file ['nameWithExtension'] = "$fileNameId.$fileExtension";
				array_push ( $response ["files"], $file );
			}
		}
		
	} else if ($action=='SEND-TO-DOCK'){
		$docking_dir = "../session-files/$session_id/DOCKING";
		if(!file_exists($docking_dir) || !is_dir($docking_dir)){
			mkdir($docking_dir);
		}
		
		if(!file_exists("$docking_dir/PROTEIN") || !is_dir("$docking_dir/PROTEIN")){
			mkdir("$docking_dir/PROTEIN");
		} else {
			shell_exec("rm $docking_dir/PROTEIN/*");
		}
		
		shell_exec("cp ../session-files/$session_id/PROTEIN/* $docking_dir/PROTEIN/");
	}
}

echo json_encode ( $response );

function pdbthorboxPrepare($session_id, $file_name){
	$pdbthorbox = new Pdbthorbox($session_id);
	$prepare_result = $pdbthorbox->prepare ( $file_name );
	return $prepare_result;
}

function saveFile($file, $path_to, $fileNameIdWithExtension) {
	$utils = new Utils();
	if (! file_exists ( $path_to ) || ! is_dir ( $path_to )) {
		mkdir ( $path_to );
	} else {
		$utils->clearDir ( $path_to );
	}
	move_uploaded_file ( $file ['tmp_name'], "$path_to/" . $fileNameIdWithExtension );
	return $file;
}
?>